#include <iostream>

int main(int, char* [])
{
  return 0;
}
