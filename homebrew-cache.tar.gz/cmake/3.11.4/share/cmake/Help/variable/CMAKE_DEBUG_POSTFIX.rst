CMAKE_DEBUG_POSTFIX
-------------------

See variable :variable:`CMAKE_<CONFIG>_POSTFIX`.

This variable is a special case of the more-general
:variable:`CMAKE_<CONFIG>_POSTFIX` variable for the `DEBUG` configuration.
