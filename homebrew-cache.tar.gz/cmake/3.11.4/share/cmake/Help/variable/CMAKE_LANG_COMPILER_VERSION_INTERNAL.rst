CMAKE_<LANG>_COMPILER_VERSION_INTERNAL
--------------------------------------

An internal variable subject to change.

This is used to identify the variant of a compiler based on an internal
version number.  For some compilers this is needed to determine the
correct usage.
