CTEST_P4_OPTIONS
----------------

Specify the CTest ``P4Options`` setting
in a :manual:`ctest(1)` dashboard client script.
