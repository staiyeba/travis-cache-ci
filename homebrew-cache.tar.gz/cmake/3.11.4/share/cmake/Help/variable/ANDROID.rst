ANDROID
-------

Set to ``1`` when the target system (:variable:`CMAKE_SYSTEM_NAME`) is
``Android``.
