CMAKE_LINK_DEPENDS_NO_SHARED
----------------------------

Whether to skip link dependencies on shared library files.

This variable initializes the :prop_tgt:`LINK_DEPENDS_NO_SHARED` property on
targets when they are created.  See that target property for
additional information.
