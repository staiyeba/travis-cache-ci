CMAKE_ANDROID_STANDALONE_TOOLCHAIN
----------------------------------

When :ref:`Cross Compiling for Android with a Standalone Toolchain`, this
variable holds the absolute path to the root directory of the toolchain.
The specified directory must contain a ``sysroot`` subdirectory.
