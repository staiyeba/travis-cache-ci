CPACK_COMPONENT_INCLUDE_TOPLEVEL_DIRECTORY
------------------------------------------

Boolean toggle to include/exclude top level directory (component case).

Similar usage as :variable:`CPACK_INCLUDE_TOPLEVEL_DIRECTORY` but for the
component case.  See :variable:`CPACK_INCLUDE_TOPLEVEL_DIRECTORY`
documentation for the detail.
