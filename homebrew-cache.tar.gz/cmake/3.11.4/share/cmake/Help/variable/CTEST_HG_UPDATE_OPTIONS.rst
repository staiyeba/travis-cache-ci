CTEST_HG_UPDATE_OPTIONS
-----------------------

Specify the CTest ``HGUpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
