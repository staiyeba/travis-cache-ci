CTEST_LABELS_FOR_SUBPROJECTS
----------------------------

Specify the CTest ``LabelsForSubprojects`` setting
in a :manual:`ctest(1)` dashboard client script.
