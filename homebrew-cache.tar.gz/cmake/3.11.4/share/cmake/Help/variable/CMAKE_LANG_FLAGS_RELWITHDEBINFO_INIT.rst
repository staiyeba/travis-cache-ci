CMAKE_<LANG>_FLAGS_RELWITHDEBINFO_INIT
--------------------------------------

This variable is the ``RelWithDebInfo`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>_INIT` variable.
