CTEST_CUSTOM_WARNING_EXCEPTION
------------------------------

A list of regular expressions which will be used to exclude when detecting
warning messages in build outputs by the :command:`ctest_test` command.

.. include:: CTEST_CUSTOM_XXX.txt
