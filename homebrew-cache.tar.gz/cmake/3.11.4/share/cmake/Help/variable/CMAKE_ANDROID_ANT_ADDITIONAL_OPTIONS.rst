CMAKE_ANDROID_ANT_ADDITIONAL_OPTIONS
------------------------------------

Default value for the :prop_tgt:`ANDROID_ANT_ADDITIONAL_OPTIONS` target property.
See that target property for additional information.
