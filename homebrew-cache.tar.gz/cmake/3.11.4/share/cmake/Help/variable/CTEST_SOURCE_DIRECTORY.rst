CTEST_SOURCE_DIRECTORY
----------------------

Specify the CTest ``SourceDirectory`` setting
in a :manual:`ctest(1)` dashboard client script.
